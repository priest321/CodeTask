import json
import requests
import os

def lambda_handler(event, context):
    try:
        api_url = 'http://api.apis.guru/v2/list.json'
        response = requests.get(api_url)
        response_data = response.json()
        k, v = response_data.popitem()
        data = {
            "statusCode": 200,
            "body": json.dumps({
                "meta": {
                "added": v["added"],
                "preferred": v["preferred"],
                "versions": list(v["versions"].keys())
                },
                "details": {
                    "info": v["versions"]["2021-08-20"]["info"],
                    "updated": v["versions"]["2021-08-20"]["updated"],
                    "swaggerUrls": {
                        "json": v["versions"]["2021-08-20"]["swaggerUrl"],
                        "yaml": v["versions"]["2021-08-20"]["swaggerYamlUrl"]
                    },
                "openapiVersion": v["versions"]["2021-08-20"]["openapiVer"],
                "link": v["versions"]["2021-08-20"]["link"]
                }
            })
        }
        print(data)
        return data
    except Exception as e:
        os.system(f"echo '{e}' >> /home/ec2-user/code/hello/log.txt")


lambda_handler(1,1)
